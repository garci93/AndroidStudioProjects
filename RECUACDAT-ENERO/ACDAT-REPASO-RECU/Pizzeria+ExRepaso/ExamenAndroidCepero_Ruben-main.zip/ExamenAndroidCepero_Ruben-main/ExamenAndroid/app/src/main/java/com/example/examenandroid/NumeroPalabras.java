package com.example.examenandroid;

public class NumeroPalabras {

    static int numeroPalabra = 12;



    public static  int getNumeroPalabra() {
        return numeroPalabra;
    }

    public static void setNumeroPalabra(int numeroPalabranueva) {
        numeroPalabra = numeroPalabranueva;
    }
}
