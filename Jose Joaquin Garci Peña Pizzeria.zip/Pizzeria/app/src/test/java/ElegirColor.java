public class ElegirColor {
}
